<?php
// Connexion à la base de données
$user = 'root';
$pass = '';
$bdd = new PDO('mysql:host=localhost;dbname=journee_pedagogique;charset=utf8', 'root', '');
?>