	<footer class="py-5 bg-dark">
    	<div class="container">
    		<div style="text-align:center;" class="row">
	      		<div class="col-lg-4 mb-4">
	      			<img alt="Logo Saint-Vincent" src="img/header_footer/logo_footer.jpg">
	      		</div>
	      		<div class="col-lg-4 mb-4">
	      			<p style="color:rgba(255,255,255,0.4);">Lycée privé Saint-Vincent <br>30 rue de Meaux B.P 20088 <br>60304 SENLIS CEDEX-France</p>
	      		</div>
	      		<div class="col-lg-4 mb-4">
	      		<ul class="social">
	      			<li>
	      				<a href="https://www.facebook.com/pages/Lyc%C3%A9e-St-Vincent/119093664776002?fref=ts" target="new">
	      					<i class="devicon-facebook-plain"></i>
	      				</a>
	      			</li>
	      			<li>
	      				<a href="https://twitter.com/stvincentsenlis" target="new">
	      					<i class="devicon-twitter-plain"></i>
	      				</a>
	      			</li>
	      			<li>
	      				<a href="https://www.youtube.com/channel/UCsTG8Kp8F6Mhp5cki-BZ_lQ" target="new">
	      					<i class="fa fa-youtube-play fa-lg"></i>
	      				</a>
	      			</li>
	      		</ul>
	      		</div>
			</div>
        	<span class="realisation">Réalisation: Dylan NOALLY, Gradi MANDAMBU, Adnane ALIOUATE, Mattias MACCIOCU</p>
      	</div>
    </footer>