<?php
  session_start();
  $pagetitle = "Vidéos | Journée Pédagogique | Lycée Saint-Vincent";
  include 'view/connexionBD.php';
  include 'view/includes/header.php';
?>

    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3" align="center">Vidéos</h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Accueil</a>
        </li>
        <li class="breadcrumb-item active">Portfolio 4</li>
      </ol>

      <div class="row">
        <div class="col-lg-8">
          <div class="card-group">
            <?php
              
              $videos = 'SELECT * FROM video WHERE VID_TYPE ="live"';
              $req = $bdd->query($videos);

              while ($row = $req->fetch()) { ;?>
                  
                
                <div class="col-lg-4 portfolio-item">
                  <div class="video-container">
                    <a href="#"><iframe width="212" height="145" src="<?php echo $row['VID_Lien_modif']; ?>" frameborder="0" allowfullscreen></iframe></a>
                    <p>
                        <a id="titre" href="<?php echo $row['VID_Lien']; ?>" target="_blank"><?php $vid = preg_replace('#@#isU', ' ', $row['VID_Titre']);
                          echo $vid;
                            ?> </a>
                      <!--<p class="card-text"> <?php //echo $row['description']; ?> </p>-->
                    <p>
                  </div>
                </div>
            <?php
              };
            ?>
          </div>
        </div>

        <div class="col lg-2">
          <!-- Widget Twitter associé au compte du lycée -->
          <i class="widget">
            <a class="twitter-timeline" data-width="330" data-height="500" data-theme="dark" data-link-color="#19CF86" href="https://twitter.com/stvincentsenlis">Tweets by lycée saint vincent</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
          </i>
        </div>
        <a class="buttonImage" href="form_video.php">Ajouter video</a>


      </div>

      

      <!-- Pagination 
      <ul class="pagination justify-content-center">
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
            <span class="sr-only">Previous</span>
          </a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">1</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">2</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">3</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Next">
            <span aria-hidden="true">&raquo;</span>
            <span class="sr-only">Next</span>
          </a>
        </li>
      </ul>-->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php
      include 'view/includes/footer.php';
    ?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
