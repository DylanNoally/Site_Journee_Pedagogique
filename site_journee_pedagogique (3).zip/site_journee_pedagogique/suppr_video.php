<?php
	include 'view/connexionBD.php';

	$titre_video = $_POST['video_suppr'];

	if(isset($titre_video))
	{
		$supprVideo = 'DELETE FROM video WHERE VID_Titre = "'.$titre_video.'"';
		$req = $bdd->query($supprVideo);
	}
	header('Location: live.php');
?>