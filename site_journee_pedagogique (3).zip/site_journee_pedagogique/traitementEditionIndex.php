<?php
	session_start();
	include 'view/connexionBD.php';

	if(isset($_POST["creerbloc"]))
	{

		$req = $bdd->prepare('SELECT TEX_Id FROM texte WHERE TEX_Type = "Accueil" AND TEX_Titre like "%Bloc%" ORDER BY TEX_Type');
        $req->execute();
        $results = $req->fetchAll();
	    $varCompteur = 1;
	    foreach ($results as $compteur) 
	    {
	    	$varCompteur = $varCompteur + 1;
	    }

	    $var = "Bloc_".$varCompteur;
	    $titre = (string) $var;
		$blocVide = "Ce bloque est vide...";
		$type = "Accueil";
		// Vérification des identifiants
			$req = $bdd->prepare('INSERT INTO texte(TEX_Titre, TEX_Text, TEX_Type, UTI_Id) VALUES (:titre, :texte, :type, :login)');
			$req->execute(array(
				'titre' => $titre,
				'texte' => $blocVide,
				'type' => $type,
				'login' => $_SESSION['id']));

			echo '<script>alert("Félicitation, vous avez bien ajouté un nouveau bloc")</script>';
			header('Refresh: 0.1; URL=indexEdition.php');
	}

	if(isset($_POST["updateInfos"]))
	{
		$titreBloc = $_POST['titre'];
		$sous_titreBloc1 = $_POST['sous-titre1'];
		$sous_titreBloc2 = $_POST['sous-titre2'];
	}


	
	
?>