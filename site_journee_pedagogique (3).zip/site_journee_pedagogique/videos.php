<?php
    session_start();
    $pagetitle = "Vidéo | Journée Pédagogique | Lycée Saint Vincent";
    include 'view/includes/header.php'
?>
    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">Videos
        <small> de la journée</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Accueil</a>
        </li>
        <li class="breadcrumb-item active">Vidéos</li>
      </ol>

      <div class="row">
        <?php
          $videos = 'SELECT * FROM video';
          $req = $bdd->query($videos);
          while ($row = $req->fetch()) { ;?>
              
            
            <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
              <div class="card h-100">
                <a href="#"><iframe width="255" height="145" src="<?php echo $row['lien']; ?>" frameborder="0" allowfullscreen></iframe></a>
                <div class="card-body">
                  <h4 class="card-title">
                    <a href="#"> <?php echo $row['titre']; ?> </a>
                  </h4>
                  <p class="card-text"> <?php echo $row['description']; ?> </p>
                </div>
              </div>
            </div>
        <?php
          };
        ?>
        
      </div>

      <!-- Widget Twitter associé au compte du lycée -->
      <div>
        <a class="twitter-timeline" data-width="300" data-height="500" data-theme="dark" data-link-color="#19CF86" href="https://twitter.com/stvincentsenlis">Tweets by lycée saint vincent</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
      </div>

      <!-- Pagination -->
      <ul class="pagination justify-content-center">
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
            <span class="sr-only">Previous</span>
          </a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">1</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">2</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#">3</a>
        </li>
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Next">
            <span aria-hidden="true">&raquo;</span>
            <span class="sr-only">Next</span>
          </a>
        </li>
      </ul>

    </div>
    <!-- /.container -->
    <?php
      include 'view/includes/footer.php';
    ?>
    <!-- Footer -->