<?php
  session_start();
  $pagetitle = "Vidéos | Journée Pédagogique | Lycée Saint Vincent";
  include 'view/connexionBD.php';
  include 'view/includes/header.php';
?>

  		<?php
			$type = "live";
			$idUser = $_SESSION['id'];

			if (isset($_POST['url']))
			{
				$url = $_POST['url'];

				if (preg_match('#https:\/\/www\.youtube\.[a-zA-Z]{2,3}(.*)#', $url)==0) {
					?>
					<script type="text/javascript"> alert("Le lien n'est pas valide"); </script>

					<?php
				}
				else {

					include 'aspiration.php';
					$titre = getTitle($url);
					$titre = preg_replace('# #isU', '@', $titre);
					//conversion du lien pour que la video s'affiche
					$lien = preg_replace('#watch\?v=#isU', 'embed/', $url);

					var_dump($lien);
					var_dump($titre);
					var_dump($url);
					$nouvVideo = $bdd->prepare('INSERT INTO video(VID_Lien, VID_Lien_modif, VID_Titre, VID_Type, UTI_Id) VALUES ("'.$url.'", "'.$lien.'", "'.$titre.'", "'.$type.'", "'.$idUser.'")');
					$nouvVideo->execute();
					var_dump($nouvVideo);
					?>
					<script type="text/javascript"> alert("La vidéo a été ajoutée"); </script>
					<?php
				}

			}

		?>

		<div id="content" align="center">
			<h1>Gestion des vidéos</h1>
			<br>
			<form method="POST" action="form_video.php">
				<h2>Ajouter une nouvelle vidéo :</h2>
				<br>
				<label for="lienVideo">Lien :</label>
				<input id="lienVideo" class="champ" name="url" required/><!--form-control-->
				<button class="btn">Valider</button>
			</form>
		</div>

		<hr>

		<div id="content" align="center">
			<form action='suppr_video.php' method="POST">
				<h2>Supprimer une vidéo :</h2>
				<br>
				<label for="titreVideo"> video :</label>
				<select id="titreVideo" name="video_suppr">
					<?php
						$video = 'SELECT * FROM video WHERE VID_Type = "live"';
						$req = $bdd->query($video);

						while ($row = $req->fetch()) 
						{
							echo "<option value=".$row['VID_Titre'].">";
							// remplacement des @ par des espaces pour l'affichage
							$vid = preg_replace('#@#isU', ' ', $row['VID_Titre']);
							echo $vid;
							echo "</option>";
						};
					?>
				</select>
				<button class="btn">Valider</button>
			</form>
		</div>
		<?php
			include 'view/includes/footer.php';
		?>
	</body>
</html>