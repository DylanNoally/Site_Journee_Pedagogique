<?php
    session_start();
    $pagetitle = "Journée Pédagogique | Lycée Saint Vincent";
    include 'view/connexionBD.php';
    include 'view/includes/header.php';
?>

    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('img/header_footer/bts-sio.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <!-- Slide Two - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('img/header_footer/bts-sio2.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <!-- Slide Three - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('img/header_footer/lycee_st_vincent-espaceAdmin.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>

    <!-- Page Content -->
    <div class="container">

      <h1 class="my-4" align="center"><i><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Titre" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></i></h1>

      <!-- Marketing Icons Section -->
      <div class="row">
        <div class="col-lg-6 mb-4">
          <div class="card h-100">
            <h4 class="card-header" align="center"><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Sous-titre_1" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></h4>
          </div>
        </div>
        <div class="col-lg-6 mb-4">
          <div class="card h-100">
            <h4 class="card-header" align="center"><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Sous-titre_2" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></h4>
          </div>
        </div>

          <?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Type = "Accueil" AND TEX_Titre like "%Bloc%" ORDER BY TEX_Type');
            $req->execute();
            $results = $req->fetchAll();
            foreach ($results as $blocTexte) 
            {?>
              <div class="col-lg-12 mb-4">          
                <div class="h-100">
                  <div class="card-body">
                    <p class="card-text">
                      <?php
                      $var = str_replace("\n", "<br/>", $blocTexte);
                      echo $var['TEX_Text']; ?>
                    </p>
                  </div>
                </div>
              </div>
            <?php
            }
            ?></p>
      </div>
      <!-- /.row -->
      <?php
      if (key_exists('login', $_SESSION) && key_exists('id', $_SESSION)) 
      {
      ?>
        <div class="mb-4" align="center">
          <div class="col-md-6">
            <a class="btn btn-lg btn-secondary btn-block" style="background-color:#19253D;" href="indexEdition.php">Modifier les informations</a>
          </div>
        </div>
      <?php
      }
      ?>
      <!-- Call to Action Section -->
      <div class="mb-4">
        <div class="col-md-12">
          <a class="btn btn-lg btn-secondary btn-block" href="#">Revenir en haut !</a>
        </div>
      </div>

    </div>
    <!-- /.container -->
    <?php
      include 'view/includes/footer.php';
    ?>
    <!-- Footer -->
    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
