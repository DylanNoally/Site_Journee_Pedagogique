<?php
    session_start();
    $pagetitle = "Journée Pédagogique | Lycée Saint-Vincent";
    include 'view/connexionBD.php';
    include 'view/includes/header.php';

    $req = $bdd->prepare('SELECT TEX_Id FROM texte WHERE TEX_Type = "Accueil" AND TEX_Titre like "%Bloc%" ORDER BY TEX_Type');
    $req->execute();
    $results = $req->fetchAll();
?>
<?php
  if (isset($_SESSION['login']) && isset($_SESSION['id']))
  {
  ?>
    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('bts-sio.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <!-- Slide Two - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('bts-sio2.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <!-- Slide Three - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('lycee_st_vincent-espaceAdmin.jpg')">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Précédent</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Suivant</span>
        </a>
      </div>
    </header>

    <!-- Page Content -->
    <div class="container">
    <form action="indexEdition.php" method="POST">

      <h1 class="my-4" align="center"><textarea name="titre" value="titre" cols="40" rows=2><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Titre" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></textarea></h1>

      <!-- Marketing Icons Section -->
      <div class="row">
        <div class="col-lg-6 mb-4">
          <div class="card h-100">
            <h4 class="card-header" align="center"><textarea name="sous_titre1" value="sous_titre1" cols="38" rows=2><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Sous-titre_1" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></textarea></h4>
          </div>
        </div>
        <div class="col-lg-6 mb-4">
          <div class="card h-100">
            <h4 class="card-header" align="center"><textarea name="sous_titre2" value="sous_titre2" cols="40" rows=2><?php 
            $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Sous-titre_2" AND TEX_Type = "Accueil"');
            $req->execute();
            $affiche = $req->fetch();
            echo $affiche['TEX_Text'];?></textarea></h4>
          </div>
        </div>
        <div class="col-lg-12 mb-4">          
          <div class="h-100">
            <div class="card-body">
              <p class="card-text" align="center">
                <textarea name="bloc1" value="bloc1" cols="40" rows=5><?php
                  $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Bloc_1" AND TEX_Type = "Accueil"');
                  $req->execute();
                  $affiche = $req->fetch();
                  $var = str_replace("\n", "<br/>", $affiche);
                  echo $var['TEX_Text']?></textarea>
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-12 mb-4">          
          <div class="h-100">
            <div class="card-body">
              <p class="card-text" align="center">
                <textarea name="bloc2" value="bloc2" cols="40" rows=5><?php
                  $req = $bdd->prepare('SELECT TEX_Text FROM texte WHERE TEX_Titre = "Bloc_2" AND TEX_Type = "Accueil"');
                  $req->execute();
                  $affiche = $req->fetch();
                  $var = str_replace("\n", "<br/>", $affiche);
                  echo $var['TEX_Text']?></textarea>
              </p>
            </div>
          </div>
        </div>
      </div>
      <button class="col-lg-12 mb-4 btn btn-lg btn-secondary btn-block" type="submit" name="updateInfos" style="background-color:#19253D;color:white;">Mettre à jour les informations saisies</button>
    </form>
      <?php
      if(isset($_POST["updateInfos"]) && !empty($_POST["titre"]) && !empty($_POST["sous_titre1"]) && !empty($_POST["sous_titre2"]) && (!empty($_POST["bloc1"]) || !empty($_POST["bloc2"])))
      {
        $titre = $_POST['titre'];
        $sous_titre1 = $_POST['sous_titre1'];
        $sous_titre2 = $_POST['sous_titre2'];
        $bloc1 = $_POST['bloc1'];
        $bloc2 = $_POST['bloc2'];
        $idUser = $_SESSION['id'];

        $req = $bdd->prepare('UPDATE texte SET TEX_Text = "'.$titre.'", UTI_Id = "'.$idUser.'" WHERE TEX_Type = "Accueil" AND TEX_Titre = "Titre"');
        $req->execute();

        $req = $bdd->prepare('UPDATE texte SET TEX_Text = "'.$sous_titre1.'", UTI_Id = "'.$idUser.'" WHERE TEX_Type = "Accueil" AND TEX_Titre = "Sous-titre_1"');
        $req->execute();

        $req = $bdd->prepare('UPDATE texte SET TEX_Text = "'.$sous_titre2.'", UTI_Id = "'.$idUser.'" WHERE TEX_Type = "Accueil" AND TEX_Titre = "Sous-titre_2"');
        $req->execute();

        $req = $bdd->prepare('UPDATE texte SET TEX_Text = "'.$bloc1.'", UTI_Id = "'.$idUser.'" WHERE TEX_Type = "Accueil" AND TEX_Titre = "Bloc_1"');
        $req->execute();

        $req = $bdd->prepare('UPDATE texte SET TEX_Text = "'.$bloc2.'", UTI_Id = "'.$idUser.'" WHERE TEX_Type = "Accueil" AND TEX_Titre = "Bloc_2"');
        $req->execute();
      }
      ?>
  <?php
  }
  else
  {
    header('Location: index.php');
  }
  ?>
      <!-- /.row -->
    </div>
    <!-- /.container -->
    <?php
      include 'view/includes/footer.php';
    ?>
    <!-- Footer -->
    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
