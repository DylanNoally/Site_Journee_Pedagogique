<?php
    session_start();
    $pagetitle = "Programme | Journée Pédagogique | Lycée Saint Vincent";
    include 'view/includes/header.php';
?>
    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3" align="center">Programme</h1>
      
      <hr>

      <!-- Project One -->
      <div class="row">
        <div class="col-md-5">
          <a href="#">
            <img class="img-fluid rounded mb-3 mb-md-0" src="http://placehold.it/700x300" alt="">
          </a>
        </div>
        <div class="col-md-7">
          <h3>9H00-12H15</h3>
          <p>World Café: Recueillir les idées de chacun et faire circuler notre vision de la pédagogie. 
             Échanger pour construire ensemble la réponse à cette question  grâce à 6 tours de table : 
             comment fait-on réussir nos élèves ? L'esprit Saint-Vincent, c'est ...?</p>
        </div>
      </div>
      <!-- /.row -->

      <hr>

      <!-- Project Two -->
      <div class="row">
        <div class="col-md-7">
          <h3> 12H15-14H00</h3>
          <p>Déjeuner offert par l'établissement.</p>
        </div>
        <div class="col-md-5">
          <a href="#">
            <img class="img-fluid rounded mb-3 mb-md-0" src="http://placehold.it/700x300" alt="">
          </a>
          
        </div>
      </div>
      <!-- /.row -->

      <hr>

      <!-- Project Three -->
      <div class="row">
        <div class="col-md-5">
          <a href="#">
            <img class="img-fluid rounded mb-3 mb-md-0" src="http://placehold.it/700x300" alt="">
          </a>
        </div>
        <div class="col-md-7">
          <h3>14H00-15H30</h3>
          <p>Enseigner autrement : conférence de Jean-Claude Caillez sur "la classe renversée, c'est renversant"
             Jean-Claude Caillez, Vice-président Innovation de l’Université catholique de Lille, professeur de biologie cellulaire et moléculaire présente son travail fondé sur de nouvelles formes de pédagogie, sur le travail collaboratif et la créativité.</p>
        </div>
      </div>
      <!-- /.row -->

      <hr>

      <!-- Project Four -->
      <div class="row">

        <div class="col-md-7">
          <h3>15H30-16H00</h3>
          <p>Retour sur la journée avec P. Revello et A. Stauder
             Nous ferons une synthèse des premiers résultats du World Café du matin afin de mettre en route la construction du projet d'établissement.</p>
        </div>
        <div class="col-md-5">
          <a href="#">
            <img class="img-fluid rounded mb-3 mb-md-0" src="http://placehold.it/700x300" alt="">
          </a>
        </div>
      </div>
      <!-- /.row -->

      <hr>
    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php
      include 'view/includes/footer.php';
    ?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
