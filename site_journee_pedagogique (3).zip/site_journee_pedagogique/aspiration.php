<?php

	function getTitle($url)
	{
		$page = file_get_contents($url);
		

		//titre
		preg_match_all('#<h1(.*)>(.*)<\/h1>#isU', $page, $title);
		preg_match_all('#<span(.*)>(.*)</span>#isU', $title[0][1], $title);
		$titre = trim($title[2][0]);
		return $titre;
	}

	



?>