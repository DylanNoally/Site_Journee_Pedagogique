-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Ven 20 Octobre 2017 à 17:00
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `journee_pedagogique`
--

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE `images` (
  `IMA_Id` int(255) NOT NULL,
  `IMA_Titre` varchar(255) DEFAULT NULL,
  `IMA_Description` varchar(255) DEFAULT NULL,
  `IMA_Chemin` varchar(500) DEFAULT NULL,
  `IMA_Type` varchar(50) DEFAULT NULL,
  `UTI_Id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `images`
--

INSERT INTO `images` (`IMA_Id`, `IMA_Titre`, `IMA_Description`, `IMA_Chemin`, `IMA_Type`, `UTI_Id`) VALUES
(1, NULL, NULL, 'img/retour/bts-sio.jpg', 'Illustration de la journée', 1),
(2, NULL, NULL, 'img/retour/carte mentale.jpg', 'Carte mentale de la journée', 1),
(3, NULL, NULL, 'img/retour/test_image1.jpg', 'Illustration de la journée', 1),
(4, NULL, NULL, 'img/retour/test_image2.jpg', 'Illustration de la journée', 1),
(5, NULL, NULL, 'img/retour/test_image3.jpg', 'Illustration de la journée', 1),
(6, NULL, NULL, 'img/retour/test_image6.jpg', 'Illustration de la journée', 1),
(7, NULL, NULL, 'img/retour/test_image8.jpg', 'Illustration de la journée', 1);

-- --------------------------------------------------------

--
-- Structure de la table `texte`
--

CREATE TABLE `texte` (
  `TEX_Id` int(255) NOT NULL,
  `TEX_Titre` varchar(255) DEFAULT NULL,
  `TEX_Text` text NOT NULL,
  `TEX_Type` varchar(50) NOT NULL,
  `UTI_Id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `texte`
--

INSERT INTO `texte` (`TEX_Id`, `TEX_Titre`, `TEX_Text`, `TEX_Type`, `UTI_Id`) VALUES
(1, 'Titre', 'Construire notre projet d\'établissement :  ', 'Accueil', 1),
(2, 'Sous-titre_1', 'L\'esprit Saint-Vincent aujourd\'hui, c\'est ... ?', 'Accueil', 1),
(3, 'Sous-titre_2', 'Comment faire réussir nos élèves... ?', 'Accueil', 1),
(4, 'Bloc_1', 'Saint-Vincent, c\'est une longue histoire, un établissement qui s\'est construit au fil des ans grâce à l\'investissement  de ses professeurs. Quelle feuille de route voulons-nous pour les années à venir ? Retrouvons-nous le lundi 20 novembre pour écrire une nouvelle page de notre histoire et entreprenons  la construction du nouveau projet d\'établissement  en répondant à ces deux questions : \n\n                                       Comment fait-on réussir nos élèves ? L\'esprit Saint-Vincent aujourd\'hui , c\'est ... ?\n\nPour récolter vos réponses à ces deux questions lors de cette journée pédagogique, nous vous proposons de participer à un World Café. Le "World Café" est un processus créatif qui vise à faciliter  le partage de connaissances et d’idées en vue de créer un réseau d’échanges et d’actions. Ce processus reproduit l’ambiance d’un café dans lequel les participants débattent d’une question en petits groupes autour de tables. ', 'Accueil', 1),
(5, 'Bloc_2', 'Les participants répondront aux deux questions suivantes  "Comment fait-on réussir nos élèves aujourd\'hui  ? L\'esprit Saint-Vincent, c\'est ... ?" en abordant 6 pôles différents au cours de la matinée :\n\n• Orienter avec efficacité grâce aux enseignements d’exploration \n• Faire le lien entre collège et lycée \n• Innover dans ses cours \n• Mettre en valeur les projets et communiquer \n• S’ouvrir à l’international \n• Valoriser la voie technologique \n\nDeux intervenants à chaque table vous accueilleront pour vous présenter leur pôle et recueillir vos idées et votre sentiment sur la question. \nToutes les 25 minutes, les participants changent de table. Un intervenant accueille les nouveaux participants  à la table et leur résume la conversation précédente. Les conversations en cours sont alors "fécondées" avec les idées issues des conversations précédentes avec les autres participants. \nLes principales idées recueillies seront résumées au cours de la plénière en fin d\'après-midi  et serviront de premiers jalons pour la construction du projet d\'établissement. \n', 'Accueil', 1);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `UTI_Id` int(255) NOT NULL,
  `UTI_Login` varchar(255) NOT NULL,
  `UTI_Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`UTI_Id`, `UTI_Login`, `UTI_Password`) VALUES
(1, 'idasiak', 'db0bc01cafdcc5adfb51f6844b2d7ab21963ee5d');

-- --------------------------------------------------------

--
-- Structure de la table `video`
--

CREATE TABLE `video` (
  `VID_Id` int(255) NOT NULL,
  `VID_Date` date DEFAULT NULL,
  `VID_Lien` varchar(500) DEFAULT NULL,
  `VID_Lien_modif` varchar(355) DEFAULT NULL,
  `VID_Titre` varchar(255) DEFAULT NULL,
  `VID_Type` varchar(50) DEFAULT NULL,
  `UTI_Id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `video`
--

INSERT INTO `video` (`VID_Id`, `VID_Date`, `VID_Lien`, `VID_Lien_modif`, `VID_Titre`, `VID_Type`, `UTI_Id`) VALUES
(16, NULL, 'https://www.youtube.com/watch?v=oAiseNw9M18', 'https://www.youtube.com/embed/oAiseNw9M18', 'Interview@de@M.Chodorge@-@Lycee@Saint-Vincent@-@Senlis', 'live', 1),
(18, NULL, 'https://www.youtube.com/watch?v=oAiseNw9M18', 'https://www.youtube.com/embed/oAiseNw9M18', 'Interview@de@M.Chodorge@-@Lycee@Saint-Vincent@-@Senlis', 'live', 1),
(19, NULL, 'https://www.youtube.com/watch?v=oAiseNw9M18', 'https://www.youtube.com/embed/oAiseNw9M18', 'Interview@de@M.Chodorge@-@Lycee@Saint-Vincent@-@Senlis', 'live', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`IMA_Id`),
  ADD KEY `#UTI_Id` (`UTI_Id`);

--
-- Index pour la table `texte`
--
ALTER TABLE `texte`
  ADD PRIMARY KEY (`TEX_Id`),
  ADD KEY `#UTI_Id` (`UTI_Id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`UTI_Id`);

--
-- Index pour la table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`VID_Id`),
  ADD KEY `VID_Id` (`VID_Id`),
  ADD KEY `#UTI_Id` (`UTI_Id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `images`
--
ALTER TABLE `images`
  MODIFY `IMA_Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `texte`
--
ALTER TABLE `texte`
  MODIFY `TEX_Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `UTI_Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `video`
--
ALTER TABLE `video`
  MODIFY `VID_Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `UTI_Id` FOREIGN KEY (`UTI_Id`) REFERENCES `utilisateur` (`UTI_Id`);

--
-- Contraintes pour la table `texte`
--
ALTER TABLE `texte`
  ADD CONSTRAINT `key` FOREIGN KEY (`UTI_Id`) REFERENCES `utilisateur` (`UTI_Id`);

--
-- Contraintes pour la table `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `cccc` FOREIGN KEY (`UTI_Id`) REFERENCES `utilisateur` (`UTI_Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
